#pragma once
#include <string>
#include <vector>

namespace features::modelchanger {

    void initialize ();
    void scan_models ();
    void on_frame_stage_notify (int stage);

    extern int g_selected_index;
    extern bool g_need_set_model;
    extern std::vector<std::pair<std::string, std::string>> g_models;
}