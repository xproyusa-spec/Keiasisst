#include <pch/pch.hpp>
#include "modelchanger.hpp"
#include <utilities/memory/memory.hpp>
#include <core/systems/systems.hpp>
#include <core/settings.hpp>
#include <filesystem>
#include <Windows.h>

namespace fs = std::filesystem;

namespace features::modelchanger {

    int g_selected_index = 0;
    bool g_need_set_model = false;
    std::vector<std::pair<std::string, std::string>> g_models;

    uintptr_t fn_set_model_addr = 0;
    uintptr_t fn_precache_addr = 0;
    void* irs_ptr = nullptr;

    struct CBufferString {
        int m_nLength;
        int m_nAllocatedSize;
        union {
            char* m_pString;
            char m_szString [8];
        };

        CBufferString () : m_nLength (0), m_nAllocatedSize (0x80000000 | 0x40000000 | 8) {
            m_pString = nullptr;
        }

        void insert (int index, const char* str, int length, bool b1) {
            static auto fn_insert_s = reinterpret_cast<const char* (__fastcall*)(void*, int, const char*, int, bool)>(
                GetProcAddress (GetModuleHandleA ("tier0.dll"), "?Insert@CBufferString@@QEAAPEBDHPEBDH_N@Z")
            );
            if (fn_insert_s) fn_insert_s (this, index, str, length, b1);
        }
    };

    void scan_models () {
        g_models.clear ();
        g_models.push_back ({"[ OFF ]", ""});

        char cwd [MAX_PATH];
        GetCurrentDirectoryA (MAX_PATH, cwd);
        std::string root = cwd;

        auto pos = root.find ("bin\\win64");
        if (pos != std::string::npos) {
            root.replace (pos, 9, "csgo\\characters\\models");
        }

        int scanned_count = 0;
        if (fs::exists (root)) {
            for (auto& p : fs::recursive_directory_iterator (root)) {
                if (p.path ().extension () == ".vmdl_c") {
                    std::string full = p.path ().string ();
                    std::string rel = full.substr (full.find ("characters\\"));
                    std::replace (rel.begin (), rel.end (), '\\', '/');
                    rel = rel.substr (0, rel.find (".vmdl_c")) + ".vmdl";

                    std::string fname = p.path ().stem ().string ();
                    g_models.push_back ({fname, rel});
                    scanned_count++;
                }
            }
        }
    }

    void initialize () {
        scan_models ();

        HMODULE client = GetModuleHandleA ("client.dll");
        HMODULE res_sys = GetModuleHandleA ("resourcesystem.dll");

        if (client) {
            // �rnek pattern veya adres atamalar�
            fn_set_model_addr = (uintptr_t) utilities::find_pattern (client, "40 53 48 83 EC 20 48 8B D9 4C 8B C2 48 8B 0D ?? ?? ?? ?? 48 8D 54 24");
        }

        if (res_sys) {
            uintptr_t ci_addr = (uintptr_t) utilities::find_pattern (res_sys, "4C 8B 0D ?? ?? ?? ?? 4C 8B D2 4C 8B D9");
            if (ci_addr) {
                typedef void* (*CreateInterfaceFn)(const char*, int*);
                // Offset veya relative ��zme gerekebilir, �imdilik temel mant�k
            }
            fn_precache_addr = (uintptr_t) utilities::find_pattern (res_sys, "40 53 55 57 48 81 EC 80 00 00 00 48 8B 01 49 8B E8 48 8B FA");
        }
    }

    void change_model_now () {
        if (g_selected_index <= 0 || g_selected_index >= g_models.size ()) return;
        std::string path = g_models [g_selected_index].second;
        if (path.empty ()) return;

        // Senin projendeki sistem yap�s�n� kullanarak local player'� �ekiyoruz
        const auto local = systems::g_local.get ();
        if (!local.is_alive || !local.pawn) return;

        if (irs_ptr && fn_precache_addr) {
            CBufferString names;
            names.insert (0, path.c_str (), -1, false);
            typedef void* (*precache_fn)(void*, void*, const char*);
            ((precache_fn) fn_precache_addr)(irs_ptr, &names, "");
        }

        if (fn_set_model_addr) {
            typedef void* (*set_model_fn)(uintptr_t, const char*);
            ((set_model_fn) fn_set_model_addr)(local.pawn, path.c_str ());
        }

        g_need_set_model = false;
    }

    void on_frame_stage_notify (int stage) {
        // FRAME_RENDER_END kontrol�
        if (stage == 6 && g_need_set_model) {
            change_model_now ();
        }
    }
}