#include <pch/pch.hpp>
#include <core/settings.hpp>
#include <core/features/features.hpp>

#include "../../rendering.hpp"
extern void unload_cheat ();

namespace rendering {

	namespace detail {

		constexpr const char* sound_types[ ]{ "shop click", "home click", "bell", "killcard", "bullet casing", "coin pickup", "item drop", "popcan", "key press", "custom" };
		constexpr auto k_sound_type_count{ static_cast< int >( std::size( sound_types ) ) };

		void draw_custom_sound_picker( config::str& file_setting, std::string_view combo_label, std::string_view preview_id, float preview_volume )
		{
			const auto files = features::misc::impacts::list_custom_sounds( );

			static std::vector<std::string> cached_files{};
			static std::vector<const char*> cached_ptrs{};
			cached_files = files;
			cached_ptrs.clear( );
			cached_ptrs.reserve( cached_files.size( ) );

			for ( const auto& file : cached_files )
			{
				cached_ptrs.push_back( file.c_str( ) );
			}

			if ( !cached_ptrs.empty( ) )
			{
				auto selected{ 0 };
				for ( auto i = 0; i < static_cast< int >( cached_files.size( ) ); ++i )
				{
					if ( cached_files[ static_cast< std::size_t >( i ) ] == file_setting.value )
					{
						selected = i;
						break;
					}
				}

				if ( xui::combo( combo_label, selected, cached_ptrs.data( ), static_cast< int >( cached_ptrs.size( ) ) ) )
				{
					file_setting = cached_files[ static_cast< std::size_t >( selected ) ];
				}
			}

			xui::text_input( "file", file_setting.value, 64, "hit.wav" );

			if ( xui::button( preview_id, 96.0f, 22.0f ) )
			{
				features::misc::g_impacts.play_custom_sound( file_setting.value, preview_volume );
			}
		}
			constexpr const char* impact_types[ ]{ "overlay", "sparks", "both" };
			constexpr const char* tracer_types[ ]{ "current", "line" };

		constexpr const char* primary_weapons[ ]{ "none", "rifle", "scoped rifle", "scout", "awp", "auto sniper" };
		constexpr const char* secondary_weapons[ ]{ "none", "dual elites", "five-seven/tec-9", "deagle", "revolver" };
		constexpr const char* grenade_names[ ]{ "molotov", "he grenade", "smoke", "flashbang", "decoy" };

		constexpr const char* hat_types[ ]{ "kasa", "bucket" };

	} // namespace detail

	void menu::draw_misc( float group_w ) const
	{
		auto& m = settings::g_misc;

		const auto wx = this->m_x;
		const auto wy = this->m_y;
		const auto content_x = this->m_body_x;
		const auto body_y = this->m_body_y;
		const auto content_w = this->m_body_w;
		const auto col_w = ( content_w - tokens::gap ) * 0.5f;
		const auto right_x = content_x + col_w + tokens::gap;

		const auto subtab = this->m_subtab;

		xui::layout::set_cursor( content_x - wx, body_y - wy );

		if ( subtab == 0 )
		{
			auto& impacts = m.m_impacts;
			auto& traj = m.m_projectile_trajectory;
			auto& dlights = m.m_dlight;
			auto& pen = settings::g_combat.m_penetration_crosshair;
			auto& mov = settings::g_movement;
			auto& ab = m.m_autobuy;

			if ( xui::begin_child( "##misc_impacts", col_w ) )
			{
				xui::checkbox( "hit logs", impacts.hit_log );
				if ( xui::begin_popup( "##hitlog_popup", 220.0f ) )
				{
					xui::slider_float( "duration##hl", impacts.hit_log_duration, 0.5f, 10.0f, "%.1fs" );
					xui::end_popup( );
				}

				xui::checkbox( "console logs", impacts.console_log );
				xui::checkbox( "chat logs", impacts.chat_log );

				xui::checkbox( "miss logs", impacts.miss_log );
				if ( xui::begin_popup( "##misslog_popup", 220.0f ) )
				{
					xui::slider_float( "duration##ml", impacts.miss_log_duration, 0.5f, 10.0f, "%.1fs" );
					xui::end_popup( );
				}

				xui::checkbox( "hit sound", impacts.hit_sound );
				if ( xui::begin_popup( "##hitsound_popup", 220.0f ) )
				{
					xui::combo( "type##hs", impacts.hit_sound_type.value, detail::sound_types, detail::k_sound_type_count );

					xui::slider_float( "volume##hs", impacts.hit_sound_volume, 1.0f, 100.0f, "%.0f%%" );

					if ( impacts.hit_sound_type.value == settings::misc::impacts::sound_type::custom )
					{
						detail::draw_custom_sound_picker( impacts.custom_hit_sound, "sound##hs", "preview##hs", impacts.hit_sound_volume.value );
					}

					xui::end_popup( );
				}

				xui::checkbox( "hit marker", impacts.hit_marker );
				if ( xui::begin_popup( "##hitmarker_popup", 270.0f ) )
				{
					static const char* hitmarker_styles[] = { "classic", "diamond", "ring", "ticks", "square", "target" };
					static const char* hitmarker_animations[] = { "pop", "bloom", "pulse", "orbit", "float up", "none" };
					static const char* damage_animations[] = { "rise", "pop", "drift", "none" };

					xui::combo( "style##hm", impacts.hit_marker_style.value, hitmarker_styles, 6 );
					xui::checkbox( "crosshair marker##hm", impacts.hit_marker_crosshair );
					xui::checkbox( "3d world marker##hm", impacts.hit_marker_world );
					xui::checkbox( "wall impacts##hm", impacts.hit_marker_wall_impacts );
					xui::combo( "animation##hm", impacts.hit_marker_animation.value, hitmarker_animations, 6 );
					xui::slider_float( "duration##hm", impacts.hit_marker_duration, 0.1f, 5.0f, "%.1fs" );
					xui::slider_float( "size##hm", impacts.hit_marker_size, 4.0f, 32.0f, "%.1f" );
					xui::slider_float( "gap##hm", impacts.hit_marker_gap, 0.0f, 16.0f, "%.1f" );
					xui::slider_float( "thickness##hm", impacts.hit_marker_thickness, 0.5f, 5.0f, "%.1f" );
					xui::color_picker( "color##hm", impacts.hit_marker_color );

					xui::checkbox( "glow##hm", impacts.hit_marker_glow );
					if ( impacts.hit_marker_glow )
						xui::slider_float( "glow strength##hm", impacts.hit_marker_glow_strength, 0.0f, 2.0f, "%.2f" );

					xui::checkbox( "damage indicator##hm", impacts.damage_indicator );
					if ( impacts.damage_indicator )
					{
						xui::color_picker( "damage color##hm", impacts.damage_indicator_color );
						xui::combo( "damage animation##hm", impacts.damage_indicator_animation.value, damage_animations, 4 );
						xui::slider_float( "damage offset##hm", impacts.damage_indicator_offset, 0.0f, 80.0f, "%.0f" );
						xui::checkbox( "random position##hm", impacts.damage_indicator_random );
						if ( impacts.damage_indicator_random )
							xui::slider_float( "random radius##hm", impacts.damage_indicator_random_radius, 4.0f, 40.0f, "%.0f" );
						xui::checkbox( "damage glow##hm", impacts.damage_indicator_glow );
						if ( impacts.damage_indicator_glow )
							xui::slider_float( "damage glow strength##hm", impacts.damage_indicator_glow_strength, 0.0f, 2.0f, "%.2f" );
					}
					xui::end_popup( );
				}

				xui::checkbox( "hit effect", impacts.hit_effect );
				if ( xui::begin_popup( "##hitfx_popup", 220.0f ) )
				{
					xui::color_picker( "color##hitfx", impacts.hit_effect_color );
					xui::slider_float( "duration##hitfx", impacts.hit_effect_duration, 0.1f, 5.0f, "%.1fs" );
					xui::slider_float( "strength##hitfx", impacts.hit_effect_strength, 1.0f, 100.0f, "%.0f%%" );
					xui::end_popup( );
				}

				xui::checkbox( "death sound", impacts.death_sound );
				if ( xui::begin_popup( "##deathsound_popup", 220.0f ) )
				{
					xui::combo( "type##ds", impacts.death_sound_type.value, detail::sound_types, detail::k_sound_type_count );

					xui::slider_float( "volume##ds", impacts.death_sound_volume, 1.0f, 100.0f, "%.0f%%" );

					if ( impacts.death_sound_type.value == settings::misc::impacts::sound_type::custom )
					{
						detail::draw_custom_sound_picker( impacts.custom_death_sound, "sound##ds", "preview##ds", impacts.death_sound_volume.value );
					}

					xui::end_popup( );
				}

				xui::checkbox( "death effect", impacts.death_effect );
				if ( xui::begin_popup( "##deathfx_popup", 220.0f ) )
				{
					xui::color_picker( "color##deathfx", impacts.death_effect_color );
					xui::end_popup( );
				}

				xui::checkbox ("scoreboard weapons", m.m_scoreboard_weapons.enabled);
				if (xui::begin_popup ("##scoreboardeq_popup", 220.0f)) {
					xui::color_picker ("color##scoreboardeq", m.m_scoreboard_weapons.color);
					xui::end_popup ();
				}

				xui::checkbox( "bullet impacts", impacts.bullet_impact_effect );
				if ( xui::begin_popup( "##bulletfx_popup", 220.0f ) )
				{
					xui::combo( "type##bulletfx", impacts.bullet_impact_effect_type.value, detail::impact_types, 3 );

					const auto type = impacts.bullet_impact_effect_type.value;
					const auto show_overlay = type == settings::misc::impacts::bullet_impact_type::overlay || type == settings::misc::impacts::bullet_impact_type::both;
					const auto show_sparks = type == settings::misc::impacts::bullet_impact_type::sparks || type == settings::misc::impacts::bullet_impact_type::both;

					if ( show_overlay )
					{
						xui::slider_float( "duration##bulletfx", impacts.bullet_impact_effect_duration, 0.1f, 5.0f, "%.1fs" );
						xui::color_picker( "fill##bulletfx", impacts.bullet_impact_effect_fill_color );
						xui::color_picker( "edge##bulletfx", impacts.bullet_impact_effect_edge_color );

						xui::checkbox( "glow##bulletfx", impacts.bullet_impact_effect_glow );
						if ( impacts.bullet_impact_effect_glow )
						{
							xui::slider_float( "glow strength##bulletfx", impacts.bullet_impact_effect_glow_strength, 0.1f, 1.0f, "%.2f" );
						}
					}

					if ( show_sparks )
					{
						xui::color_picker( "spark##bulletfx", impacts.bullet_impact_effect_color_spark );
					}

					xui::end_popup( );
				}

				xui::checkbox( "bullet tracers", impacts.bullet_tracers );
				if ( xui::begin_popup( "##tracers_popup", 220.0f ) )
				{
					xui::combo( "type##tracer", impacts.bullet_tracer_type.value, detail::tracer_types, 2 );
					xui::slider_float( "duration##tracer", impacts.bullet_tracer_duration, 0.1f, 5.0f, "%.1fs" );
					if ( impacts.bullet_tracer_type.value == settings::misc::impacts::bullet_tracer_type::line )
					{
						xui::slider_float( "line thickness##tracer", impacts.bullet_tracer_thickness, 0.5f, 6.0f, "%.1f" );
					}
					xui::color_picker( "color##tracer", impacts.bullet_tracer_color );
					xui::end_popup( );
				}

				xui::end_child( );
			}

				if ( xui::begin_child( "##misc_visuals", col_w ) )
				{
					xui::keybind( "menu key", m.menu_key.value );
					xui::checkbox( "projectile trajectory", traj.enabled );
				if ( xui::begin_popup( "##traj_popup", 220.0f ) )
				{
					xui::checkbox( "straight throw", traj.straight_throw );
					xui::color_picker( "held color", traj.held_color );
					xui::color_picker( "thrown color", traj.thrown_color );
					xui::color_picker( "will damage held color", traj.will_deal_damage_held_color );
					xui::color_picker( "will damage thrown color", traj.will_deal_damage_thrown_color );
					xui::end_popup( );
				}

				xui::checkbox( "dynamic light", dlights.enabled );
				if ( xui::begin_popup( "##dlight_popup", 220.0f ) )
				{
					xui::color_picker( "color##dl", dlights.color );
					xui::slider_float( "radius##dl", dlights.radius, 50.0f, 15000.0f, "%.0f" );
					xui::slider_float( "z offset##dl", dlights.z_offset, 0.0f, 100.0f, "%.0f" );
					xui::end_popup( );
				}

				xui::checkbox( "penetration crosshair", pen.enabled );
				if ( xui::begin_popup( "##pen_popup", 220.0f ) )
				{
					xui::checkbox( "glow##pen", pen.glow );
					xui::slider_float( "glow strength##pen", pen.glow_strength, 0.1f, 1.0f, "%.2f" );
					xui::color_picker( "can penetrate##pen", pen.can_penetrate_fill );
					xui::color_picker( "can pen outline##pen", pen.can_penetrate_outline );
					xui::color_picker( "blocked##pen", pen.blocked_fill );
					xui::color_picker( "blocked outline##pen", pen.blocked_outline );
					xui::end_popup( );
				}

				xui::end_child( );
			}

			xui::layout::set_cursor( right_x - wx, body_y - wy );

			if ( xui::begin_child( "##misc_movement", col_w ) )
			{
				xui::checkbox( "bhop", mov.bhop );
				xui::checkbox( "airstrafe", mov.airstrafe );

				// Keep the popup immediately after the widget it configures.
				// begin_popup() anchors to the last submitted item, so inserting
				// another checkbox before it makes the action button appear on the
				// wrong row (and shifts the airstrafe submenu to quick stop).
				if ( xui::begin_popup( "##airstrafe_popup", 240.0f ) )
				{
					xui::checkbox( "fully directional", mov.airstrafe_fully_directional );
					xui::slider_float( "boost", mov.airstrafe_boost, 0.50f, 3.00f, "%.2fx" );
					xui::checkbox( "ramp boost", mov.airstrafe_ramp_boost );
					xui::end_popup( );
				}

				xui::checkbox( "quick stop", mov.quickstop );

					xui::checkbox( "subtick strafer", mov.m_test_strafer.enabled );
				xui::checkbox( "jumpbug", mov.jumpbug );
				xui::checkbox( "fastladder", mov.fastladder );
				xui::checkbox( "edgejump", mov.edgejump );
				xui::checkbox( "edgestop", mov.edgestop );
				xui::checkbox( "edgebug", mov.edgebug );
				if ( xui::begin_popup( "##edgebug_popup", 240.0f ) )
				{
					static const char* edgebug_modes[] = { "0: loose", "1: edge trace (default)", "2: no jump held", "3: min speed", "4: strict vz" };
					xui::combo( "mode##eb", mov.edgebug_mode.value, edgebug_modes, 5 );
					xui::slider_int( "passes##eb", mov.edgebug_passes, 1, 5, "%d" );
					xui::checkbox( "jump steps##eb", mov.edgebug_include_jump_steps );
					xui::end_popup( );
				}
				xui::checkbox( "slowwalk", mov.slowwalk );

				if ( xui::begin_popup( "##slowwalk_popup", 220.0f ) )
				{
					xui::slider_float( "speed", mov.slowwalk_speed, 1.0f, 100.0f, "%.2fs" );
					xui::end_popup( );
				}

				xui::end_child( );
			}

				if ( xui::begin_child( "##misc_other", col_w ) )
				{
					xui::checkbox( "reveal radar", m.reveal_radar );
					xui::checkbox( "show keybinds", m.show_keybinds );
					xui::checkbox( "spectator list", settings::g_esp.m_other.spectator_list );
						xui::checkbox( "bomb timer", settings::g_esp.m_other.bomb_timer );
						constexpr const char* menu_scales[ ]{ "75%", "100%", "125%", "150%" };
							xui::combo( "menu scale", m.menu_scale.value, menu_scales, 4 );
							xui::slider_float( "ui animation speed", m.ui_animation_speed, 0.0f, 2.0f, "%.2fx" );
						xui::slider_float( "element corner radius", m.menu_rounding, 0.0f, 24.0f, "%.0f" );
						xui::slider_float( "program corner radius", m.menu_window_rounding, 0.0f, 32.0f, "%.0f" );
						xui::slider_float( "menu opacity", m.menu_opacity, 0.35f, 1.0f, "%.2f" );
						xui::checkbox( "menu backdrop blur", m.menu_background_blur );
						xui::checkbox( "osd backdrop blur", m.osd_background_blur );
						xui::checkbox( "watermark backdrop blur", m.watermark_background_blur );
						xui::slider_float( "blur strength", m.ui_blur_strength, 0.0f, 1.0f, "%.2f" );
						static xui::setting reset_menu_size{ false, {}, "reset menu size", "misc" };
						if ( xui::checkbox( "reset menu size", reset_menu_size ) )
						{
							settings::g_misc.menu_width.value = 767.0f;
							settings::g_misc.menu_height.value = 650.0f;
							reset_menu_size.value = false;
							reset_menu_size.bind.active = false;
						}
						static xui::setting center_menu{ false, {}, "center menu", "misc" };
						if ( xui::checkbox( "center menu", center_menu ) )
						{
							const auto [ screen_w, screen_h ] = xdraw::viewport_size( );
							settings::g_misc.menu_x.value = ( static_cast< float >( screen_w ) - settings::g_misc.menu_width.value ) * 0.5f;
							settings::g_misc.menu_y.value = ( static_cast< float >( screen_h ) - settings::g_misc.menu_height.value ) * 0.5f - 40.0f;
							center_menu.value = false;
							center_menu.bind.active = false;
						}
						xui::checkbox( "asset browser", m.asset_browser );
					xui::checkbox( "preserve killfeed", m.preserve_killfeed );
				xui::checkbox( "disable game logs", m.disable_game_logs );

				xui::checkbox( "auto buy", ab.enabled );
				if ( xui::begin_popup( "##autobuy_popup", 220.0f ) )
				{
					xui::combo( "primary##ab", ab.primary_weapon, detail::primary_weapons, 6 );
					xui::combo( "secondary##ab", ab.secondary_weapon, detail::secondary_weapons, 5 );
					xui::checkbox( "armor##ab", ab.armor );
					xui::checkbox( "defuser##ab", ab.defuser );
					xui::checkbox( "taser##ab", ab.taser );
					xui::multicombo( "grenades##ab", ab.grenades, detail::grenade_names, 5 );
					xui::end_popup( );
				}

				xui::checkbox( "clantag", m.m_name_changer.clantag );
				xui::checkbox( "override name", m.m_name_changer.override_name );
				if ( xui::begin_popup( "##override_name_popup", 220.0f ) )
				{
					xui::text_input( "name##nc", m.m_name_changer.name.value, 32, "player name..." );
					xui::end_popup( );
				}

				xui::checkbox( "watermark", m.m_watermark.enabled );
				if ( xui::begin_popup( "##watermark_popup", 200.0f ) )
				{
					xui::checkbox( "fps##wm",      m.m_watermark.show_fps );
					xui::checkbox( "ping##wm",     m.m_watermark.show_ping );
					xui::checkbox( "time##wm",     m.m_watermark.show_time );
					xui::checkbox( "user##wm",     m.m_watermark.show_user );
					xui::checkbox( "map##wm",      m.m_watermark.show_map );
					xui::checkbox( "tick rate##wm",m.m_watermark.show_tick );
					xui::checkbox( "velocity##wm", m.m_watermark.show_velocity );
					xui::end_popup( );
				}
				if (xui::checkbox ("Unload", m.m_unload.enabled)) {
					if (m.m_unload.enabled) {
						unload_cheat ();
					}
				}
				xui::end_child( );
			}
		}

		if ( subtab == 1 )
		{
			auto& rem = m.m_removals;

			if ( xui::begin_child( "##misc_removals", col_w ) )
			{
				xui::checkbox( "remove crosshair", rem.crosshair );
				xui::checkbox( "remove scope", rem.scope );
				xui::checkbox( "remove overhead", rem.overhead );
				xui::checkbox( "remove legs", rem.legs );
				xui::checkbox( "remove recoil", rem.recoil );
				xui::checkbox( "remove skybox fog", rem.skybox_fog );
				xui::checkbox( "remove 3d skybox", rem.skybox_3d );
				xui::checkbox( "remove decals", rem.decals );
				xui::checkbox( "remove smoke", rem.smoke );
				xui::slider_float( "flash alpha##flash", rem.flash_alpha, 0.0f, 100.0f, "%.0f%%" );

				xui::end_child( );
			}
		}

		if ( subtab == 2 )
		{
			auto& cam = m.m_camera;
			auto& vm = m.m_viewmodel_adjust;

			if ( xui::begin_child( "##misc_camera", col_w ) )
			{
					xui::checkbox( "custom fov", cam.change_fov );
					if ( xui::begin_popup( "##fov_popup", 220.0f ) )
					{
						xui::slider_float( "fov", cam.fov, 60.0f, 150.0f, "%.0f" );
						xui::checkbox( "scoped fov override", cam.scoped_fov_override );
						xui::slider_float( "scoped fov", cam.scoped_fov, 10.0f, 90.0f, "%.0f" );
						xui::end_popup( );
					}

					xui::checkbox( "dynamic fov", cam.dynamic_fov );
					if ( xui::begin_popup( "##dynamic_fov_popup", 220.0f ) )
					{
						xui::slider_float( "speed boost", cam.dynamic_fov_amount, 0.0f, 40.0f, "+%.0f" );
						xui::slider_float( "animation speed", cam.dynamic_fov_speed, 0.25f, 15.0f, "%.2f" );
						xui::end_popup( );
					}

					xui::checkbox( "thirdperson", cam.thirdperson );
					if ( xui::begin_popup( "##tp_popup", 220.0f ) )
					{
						xui::slider_float( "distance", cam.thirdperson_distance, 35.0f, 200.0f, "%.0f" );
						xui::slider_float( "hull size", cam.thirdperson_hull_size, 0.0f, 20.0f, "%.0f" );
						xui::end_popup( );
					}
					xui::checkbox( "thirdperson location", cam.thirdperson_location );
					if ( xui::begin_popup( "##thirdperson_location_popup", 220.0f ) )
					{
						xui::slider_float( "horizontal offset", cam.thirdperson_horizontal_offset, -50.0f, 50.0f, "%.0f" );
						xui::checkbox( "horizontal offset bind", cam.thirdperson_horizontal_bind );
						xui::slider_float( "horizontal bind amount", cam.thirdperson_horizontal_bind_amount, -50.0f, 50.0f, "%.0f" );
						xui::slider_float( "vertical offset", cam.thirdperson_vertical_offset, -50.0f, 50.0f, "%.0f" );
						xui::checkbox( "vertical offset bind", cam.thirdperson_vertical_bind );
						xui::slider_float( "vertical bind amount", cam.thirdperson_vertical_bind_amount, -50.0f, 50.0f, "%.0f" );
						xui::end_popup( );
					}

					xui::checkbox( "aspect ratio", cam.change_aspect_ratio );
				if ( xui::begin_popup( "##ar_popup", 220.0f ) )
				{
					xui::slider_float( "ratio##ar", cam.aspect_ratio, 1.0f, 1.78f, "%.3f" );
					xui::end_popup( );
				}

				xui::end_child( );
			}

			xui::layout::set_cursor( right_x - wx, body_y - wy );

			if ( xui::begin_child( "##misc_viewmodel", col_w ) )
			{
				xui::checkbox( "viewmodel adjust", vm.enabled );
				if ( xui::begin_popup( "##vm_popup", 220.0f ) )
				{
					xui::slider_float( "offset x", vm.offset_x, -10.0f, 10.0f, "%.1f" );
					xui::slider_float( "offset y", vm.offset_y, -10.0f, 10.0f, "%.1f" );
					xui::slider_float( "offset z", vm.offset_z, -10.0f, 10.0f, "%.1f" );
					xui::slider_float( "fov", vm.fov, 54.0f, 90.0f, "%.0f" );
					xui::end_popup( );
				}

				xui::end_child( );
			}
		}

		if ( subtab == 3 )
		{
			auto& hud = m.m_hud;

			if ( xui::begin_child( "##misc_hud", col_w ) )
			{
				xui::checkbox( "crosshair overlay", hud.m_crosshair.enabled );
				xui::checkbox( "force crosshair", hud.m_crosshair.force_crosshair );
				if ( xui::begin_popup( "##xhair_popup", 220.0f ) )
				{
					xui::slider_float( "size##xhair", hud.m_crosshair.size, 0.5f, 10.0f, "%.1f" );
					xui::slider_float( "outline##xhair", hud.m_crosshair.outline, 0.0f, 4.0f, "%.1f" );
					xui::color_picker( "color##xhair", hud.m_crosshair.color );
					xui::color_picker( "outline color##xhair", hud.m_crosshair.outline_color );
					xui::end_popup( );
				}

				xui::checkbox( "scope overlay", hud.m_scope.enabled );
				if ( xui::begin_popup( "##scope_popup", 220.0f ) )
				{
					xui::slider_float( "line length", hud.m_scope.line_length, 10.0f, 500.0f, "%.0f" );
					xui::slider_float( "gap##scope", hud.m_scope.gap, 0.0f, 50.0f, "%.0f" );
					xui::slider_float( "thickness##scope", hud.m_scope.thickness, 0.5f, 5.0f, "%.2f" );
					xui::slider_float( "anim speed", hud.m_scope.anim_speed, 1.0f, 30.0f, "%.0f" );
					xui::checkbox( "gradient##scope", hud.m_scope.gradient );
					xui::color_picker( "inner color##scope", hud.m_scope.inner_color );
					if ( hud.m_scope.gradient )
					{
						xui::color_picker( "outer color##scope", hud.m_scope.outer_color );
					}
					xui::checkbox( "outline##scope", hud.m_scope.outline );
					if ( hud.m_scope.outline )
					{
						xui::slider_float( "outline thickness##scope", hud.m_scope.outline_thickness, 0.5f, 4.0f, "%.2f" );
						xui::color_picker( "outline color##scope", hud.m_scope.outline_color );
					}
					xui::checkbox( "center dot##scope", hud.m_scope.center_dot );
					if ( hud.m_scope.center_dot )
					{
						xui::slider_float( "dot size##scope", hud.m_scope.center_dot_size, 0.5f, 5.0f, "%.1f" );
					}
					xui::checkbox( "fade in##scope", hud.m_scope.fade_in );

					xui::layout::separator( );

					xui::checkbox( "glow##scope", hud.m_scope.glow );
					xui::slider_float( "glow strength##scope", hud.m_scope.glow_strength, 0.1f, 1.0f, "%.2f" );
					xui::end_popup( );
				}

				xui::checkbox( "speed chart", hud.m_velocity.chart );
				if ( xui::begin_popup( "##velocity_hud_popup", 220.0f ) )
				{
					xui::color_picker( "color##velocity", hud.m_velocity.color );
					xui::slider_float( "bottom offset", hud.m_velocity.bottom_offset, 20.0f, 200.0f, "%.0f" );
					xui::slider_float( "chart width", hud.m_velocity.chart_width, 120.0f, 320.0f, "%.0f" );
					xui::slider_float( "chart height", hud.m_velocity.chart_height, 24.0f, 80.0f, "%.0f" );
					xui::end_popup( );
				}

				xui::end_child( );
			}

			xui::layout::set_cursor( right_x - wx, body_y - wy );

			if ( xui::begin_child( "##misc_hud_hat", col_w ) )
			{
				xui::checkbox( "hat", hud.m_hat.enabled );
				if ( xui::begin_popup( "##hat_popup", 220.0f ) )
				{
					xui::combo( "type##hat", hud.m_hat.type.value, detail::hat_types, 2 );
					xui::color_picker( "color##hat", hud.m_hat.color );
					xui::color_picker( "secondary color##hat", hud.m_hat.secondary_color );
					xui::checkbox( "glow##hat", hud.m_hat.glow );
					xui::slider_float( "glow strength##hat", hud.m_hat.glow_strength, 0.1f, 1.0f, "%.2f" );
					xui::end_popup( );
				}

				xui::end_child( );
			}
		}
	}

} // namespace rendering
