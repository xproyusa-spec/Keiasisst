#include <pch/pch.hpp>
#include <utilities/math/math.hpp>
#include <utilities/memory/memory.hpp>
#include <utilities/addresses/addresses.hpp>
#include <core/systems/systems.hpp>
#include <core/settings.hpp>
#include <core/features/features.hpp>

#include "../rendering.hpp"
#include <utilities/security/security.hpp>

namespace rendering {

	void widgets::draw( )
	{
		auto& dl = xdraw::get( );

		if ( settings::g_misc.m_watermark.enabled.value )
		{
			this->watermark( dl );
		}

		if ( settings::g_misc.show_keybinds.value )
		{
			this->keybinds( dl );
		}
	}

	void widgets::watermark( xdraw::draw_list& draw_list )
	{
		const auto [screen_w, screen_h] = xdraw::viewport_size( );
		const auto& s  = xui::ctx( ).style;
		const auto& wm = settings::g_misc.m_watermark;
		const auto blur_strength = std::clamp( settings::g_misc.ui_blur_strength.value, 0.0f, 1.0f );
		const auto framerate = xdraw::framerate( );
		const auto local = systems::g_local.get( );

		constexpr auto margin{ 10.0f };
		constexpr auto h{ 24.0f };
		constexpr auto r{ 3.0f };
		constexpr auto inner_r{ 1.5f };
		constexpr auto inner_pad{ 2.0f };
		constexpr auto text_pad_x{ 8.0f };
		constexpr auto text_nudge{ 0.5f };
		constexpr auto section_spacing{ 2.0f };
			constexpr auto logo_icon_pad{ 7.0f };

		// ── time ────────────────────────────────────────────────────────────
		SYSTEMTIME st{};
		GetLocalTime( &st );
		char time_buf[ 8 ]{};
		std::snprintf( time_buf, sizeof( time_buf ), "%02d:%02d", st.wHour, st.wMinute );

		// ── fps ─────────────────────────────────────────────────────────────
		static auto smoothed_fps{ 0.0f };
		if ( smoothed_fps == 0.0f ) smoothed_fps = framerate;
		smoothed_fps += ( framerate - smoothed_fps ) * std::min( 2.0f * xdraw::delta_time( ), 1.0f );
		char fps_val[ 8 ]{};
		std::snprintf( fps_val, sizeof( fps_val ), "%.0f", smoothed_fps );

		// ── ping ────────────────────────────────────────────────────────────
		auto ping{ 0 };
		if ( local.is_alive && local.controller && systems::g_entities.exists( local.controller ) )
			ping = memory::read<std::uint32_t>( local.controller + SCHEMA( "CCSPlayerController", "m_iPing"_hash ) );
		char ping_val[ 8 ]{};
		std::snprintf( ping_val, sizeof( ping_val ), "%d", ping );

		// ── map name (stored reliably from level_initialization hook) ────────
		const bool has_map = wm.show_map.value && !s_map_name.empty( );

		// ── tick rate (measured from server_tick delta over ~2 s of real time) ─
		static auto last_server_tick{ 0 };
		static auto last_curtime{ 0.0f };
		static auto measured_tickrate{ 0 };

		if ( local.controller )
		{
			const auto net_for_tick = addresses::globals::network_client_service;
			const auto tick_state   = net_for_tick ? memory::call_vfunc<std::uintptr_t>( net_for_tick, 23 ) : 0;
			const auto server_tick  = tick_state   ? memory::read<int>( tick_state + 892 ) : 0;
			const auto gv           = memory::read<std::uintptr_t>( addresses::globals::global_vars );
			const auto curtime      = gv ? memory::read<float>( gv + 0x30 ) : 0.0f;

			if ( server_tick > 0 && last_server_tick > 0 && curtime - last_curtime >= 2.0f )
			{
				const auto tick_delta = server_tick - last_server_tick;
				const auto time_delta = curtime - last_curtime;
				if ( tick_delta > 0 && time_delta > 0.5f )
				{
					const auto rate = static_cast<int>( std::round( tick_delta / time_delta ) );
					if ( rate >= 16 && rate <= 256 ) measured_tickrate = rate;
				}
				last_server_tick = server_tick;
				last_curtime     = curtime;
			}
			else if ( last_server_tick == 0 && server_tick > 0 )
			{
				last_server_tick = server_tick;
				last_curtime     = curtime;
			}
		}
		else
		{
			last_server_tick = 0;
			last_curtime     = 0.0f;
			measured_tickrate = 0;
		}

		const bool has_tick = wm.show_tick.value && local.controller && measured_tickrate > 0;
		char tick_val[ 8 ]{};
		if ( has_tick ) std::snprintf( tick_val, sizeof( tick_val ), "%d", measured_tickrate );

		// ── velocity ──────────────────────────────────────────────────────
		const bool has_velocity = wm.show_velocity.value && local.is_alive && local.pawn;
		static auto smoothed_velocity{ 0.0f };
		char vel_val[ 8 ]{};
		if ( has_velocity )
		{
			const auto velocity = memory::read<math::vector3>( local.pawn + SCHEMA( "C_BaseEntity", "m_vecAbsVelocity"_hash ) );
			const auto speed = velocity.length_2d( );
			smoothed_velocity += ( speed - smoothed_velocity ) * std::min( 8.0f * xdraw::delta_time( ), 1.0f );
			std::snprintf( vel_val, sizeof( vel_val ), "%.0f", smoothed_velocity );
		}
		else
		{
			smoothed_velocity = 0.0f;
		}


			const auto inner_h     = h - inner_pad * 2.0f;
			xdraw::push_font( rendering::g_fonts.inter_bold[ rendering::fonts::size::petite ] );
			const auto [ logo_draw_w, logo_draw_h ] = xdraw::measure_text( "K" );
			xdraw::pop_font( );

		// ── measure text ─────────────────────────────────────────────────────
		const auto [name_tw, name_th] = xdraw::measure_text( "Keiassist" );
		const auto [user_tw, user_th] = xdraw::measure_text( "Alpha" );
		const auto [ping_vw, ping_vh] = xdraw::measure_text( ping_val );
		const auto [ping_uw, ping_uh] = xdraw::measure_text( " ms" );
		const auto [fps_vw,  fps_vh]  = xdraw::measure_text( fps_val );
		const auto [fps_uw,  fps_uh]  = xdraw::measure_text( " fps" );
		const auto [time_tw, time_th] = xdraw::measure_text( time_buf );

		float map_tw{}, map_th{};
		if ( has_map ) std::tie( map_tw, map_th ) = xdraw::measure_text( s_map_name.c_str( ) );

		float tick_vw{}, tick_vh{}, tick_uw{}, tick_uh{};
		if ( has_tick )
		{
			std::tie( tick_vw, tick_vh ) = xdraw::measure_text( tick_val );
			std::tie( tick_uw, tick_uh ) = xdraw::measure_text( " tick" );
		}

		float vel_vw{}, vel_vh{}, vel_uw{}, vel_uh{};
		if ( has_velocity )
		{
			std::tie( vel_vw, vel_vh ) = xdraw::measure_text( vel_val );
			std::tie( vel_uw, vel_uh ) = xdraw::measure_text( " u/s" );
		}


		// ── pill widths ──────────────────────────────────────────────────────
		const auto logo_pill_w = logo_icon_pad + logo_draw_w + logo_icon_pad + name_tw + text_pad_x;
		const auto user_pill_w = user_tw + text_pad_x * 2.0f;
		const auto ping_pill_w = ping_vw + ping_uw + text_pad_x * 2.0f;
		const auto fps_pill_w  = fps_vw  + fps_uw  + text_pad_x * 2.0f;
		const auto time_pill_w = time_tw + text_pad_x * 2.0f;
		const auto map_pill_w  = map_tw  + text_pad_x * 2.0f;
		const auto tick_pill_w = tick_vw + tick_uw + text_pad_x * 2.0f;
		const auto vel_pill_w  = vel_vw + vel_uw + text_pad_x * 2.0f;

		// ── dynamic total width ──────────────────────────────────────────────
		float target_w = inner_pad + logo_pill_w + section_spacing;
		if ( wm.show_user.value ) target_w += user_pill_w + section_spacing;
		if ( has_map )            target_w += map_pill_w  + section_spacing;
		if ( wm.show_ping.value ) target_w += ping_pill_w + section_spacing;
		if ( has_velocity )       target_w += vel_pill_w  + section_spacing;
		if ( wm.show_fps.value )  target_w += fps_pill_w  + section_spacing;
		if ( has_tick )           target_w += tick_pill_w + section_spacing;
		if ( wm.show_time.value ) target_w += time_pill_w + section_spacing;
		target_w = target_w - section_spacing + inner_pad;

		static auto smoothed_w{ 0.0f };
		if ( smoothed_w == 0.0f ) smoothed_w = target_w;
		smoothed_w += ( target_w - smoothed_w ) * std::min( 8.0f * xdraw::delta_time( ), 1.0f );

		const auto w = smoothed_w;
		const auto x = static_cast<float>( screen_w ) - w - margin;
		const auto y = margin;

		if ( settings::g_misc.watermark_background_blur.value && blur_strength > 0.01f )
		{
			draw_list.rect_filled_blurred( x, y, w, h, xdraw::corner_radius{ r },
				xdraw::color{ 255, 255, 255, static_cast<std::uint8_t>( 155.0f * blur_strength ) } );
		}
		draw_list.rect_filled_gradient( x, y, w, h,
			xdraw::color{ 17, 22, 32, s.window_bg.a }, xdraw::color{ 10, 14, 22, s.window_bg.a },
			xdraw::color{ 7, 10, 17, s.window_bg.a }, xdraw::color{ 14, 18, 27, s.window_bg.a },
			xdraw::corner_radius{ r } );
		draw_list.rect( x, y, w, h, s.text.alpha( 22 ), xdraw::corner_radius{ r }, 1.0f );
		draw_list.rect_filled_gradient( x + 8.0f, y + 1.0f, std::max( 24.0f, w * 0.24f ), 1.0f,
			s.accent.alpha( 0 ), s.accent.alpha( 165 ), s.accent.alpha( 165 ), s.accent.alpha( 0 ) );

		auto cx = x + inner_pad;

		auto draw_split_pill = [ & ]( const char* value, float vw, float vh, const char* unit, float uw, float uh, float pill_w )
			{
				draw_list.rect_filled( cx, y + inner_pad, pill_w, inner_h, s.child_bg.alpha( 218 ), xdraw::corner_radius{ inner_r } );
				draw_list.rect( cx, y + inner_pad, pill_w, inner_h, s.text.alpha( 14 ), xdraw::corner_radius{ inner_r }, 1.0f );
				draw_list.text( cx + text_pad_x, y + ( h - vh ) * 0.5f + text_nudge, value, s.accent );
				draw_list.text( cx + text_pad_x + vw, y + ( h - uh ) * 0.5f + text_nudge, unit, s.text_dim );
				cx += pill_w + section_spacing;
			};

		auto draw_pill = [ & ]( const char* text, float tw, float th, float pill_w )
			{
				draw_list.rect_filled( cx, y + inner_pad, pill_w, inner_h, s.child_bg.alpha( 218 ), xdraw::corner_radius{ inner_r } );
				draw_list.rect( cx, y + inner_pad, pill_w, inner_h, s.text.alpha( 14 ), xdraw::corner_radius{ inner_r }, 1.0f );
				draw_list.text( cx + text_pad_x, y + ( h - th ) * 0.5f + text_nudge, text, s.text );
				cx += pill_w + section_spacing;
			};

		// Branded energy capsule, using the same geometric mark as the main navigation.
		draw_list.rect_filled_gradient( cx, y + inner_pad, logo_pill_w, inner_h,
			s.accent.alpha( 235 ), s.accent.alpha( 195 ), s.accent.alpha( 160 ), s.accent.alpha( 215 ),
			xdraw::corner_radius{ inner_r } );
		const auto logo_cx = cx + logo_icon_pad + logo_draw_w * 0.5f;
		const auto logo_cy = y + h * 0.5f;
		const auto logo_r = std::max( 3.0f, logo_draw_w * 0.44f );
		draw_list.circle( logo_cx, logo_cy, logo_r, s.checkbox_mark_icon.alpha( 205 ), 1.0f );
		draw_list.circle_filled( logo_cx, logo_cy, std::max( 1.2f, logo_r * 0.28f ), s.checkbox_mark_icon );
		draw_list.line( logo_cx - logo_r * 0.8f, logo_cy + logo_r * 0.55f, logo_cx + logo_r * 0.8f, logo_cy - logo_r * 0.55f, s.checkbox_mark_icon.alpha( 180 ), 1.0f );
		draw_list.text( cx + logo_icon_pad + logo_draw_w + logo_icon_pad,
			y + ( h - name_th ) * 0.5f + text_nudge, "Keiassist", s.checkbox_mark_icon );
		cx += logo_pill_w + section_spacing;

		if ( wm.show_user.value ) draw_pill( "Alpha", user_tw, user_th, user_pill_w );
		if ( has_map )            draw_pill( s_map_name.c_str( ), map_tw, map_th, map_pill_w );
		if ( wm.show_ping.value ) draw_split_pill( ping_val, ping_vw, ping_vh, " ms",   ping_uw, ping_uh, ping_pill_w );
		if ( has_velocity )       draw_split_pill( vel_val,  vel_vw,  vel_vh,  " u/s",  vel_uw,  vel_uh,  vel_pill_w );
		if ( wm.show_fps.value )  draw_split_pill( fps_val,  fps_vw,  fps_vh,  " fps",  fps_uw,  fps_uh,  fps_pill_w );
		if ( has_tick )           draw_split_pill( tick_val, tick_vw, tick_vh, " tick", tick_uw, tick_uh, tick_pill_w );
		if ( wm.show_time.value ) draw_pill( time_buf, time_tw, time_th, time_pill_w );

	}

	void widgets::keybinds( xdraw::draw_list& draw_list )
	{
		struct row_anim_t
		{
			animation::fade alpha;
			animation::spring offset_y;
			bool active_this_frame{ false };
		};

		static std::map<std::string, row_anim_t> row_states;
		static animation::fade container_alpha;

		const auto [screen_w, screen_h] = xdraw::viewport_size( );
		const auto& s = xui::ctx( ).style;
		const auto osd_blur = settings::g_misc.osd_background_blur.value;
		const auto blur_strength = std::clamp( settings::g_misc.ui_blur_strength.value, 0.0f, 1.0f );

		constexpr auto row_spacing{ 3.0f };
		constexpr auto row_h{ 21.0f };
		constexpr auto header_h{ 24.0f };
		constexpr auto r{ 3.0f };
		constexpr auto inner_r{ 1.5f };
		constexpr auto inner_pad{ 2.0f };
		constexpr auto text_pad_x{ 8.0f };
		constexpr auto text_nudge{ 0.5f };
		constexpr auto icon_size{ 20.0f };

		struct bind_entry
		{
			const char* name;
			char value[ 32 ];
			bool has_value_pill;
			xui::bind_mode mode;
		};

		bind_entry entries[ 32 ]{};
		auto count{ 0 };

		const auto& ctx = features::combat::g_shared.ctx( );
		const auto has_weapon = ctx.valid && ctx.weapon_type >= cstypes::weapon_type::pistol && ctx.weapon_type <= cstypes::weapon_type::lmg;

		for ( const auto setting : xui::binds::all( ) )
		{
			if ( !setting || setting->bind.key == 0 || !setting->bind.active || count >= 32 )
			{
				continue;
			}

			auto is_rage_group{ false };
			for ( auto i = 0u; i < settings::combat::ragebot::k_group_count; ++i )
			{
				const auto& g = settings::g_combat.m_ragebot.groups[ i ];
				if ( setting == &g.min_damage_override || setting == &g.hitchance_override || setting == &g.force_shot || setting == &g.force_shot_air || setting == &g.body_aim || setting == &g.silent || setting == &g.no_spread )
				{
					is_rage_group = true;
					break;
				}
			}

			if ( is_rage_group )
			{
				if ( !settings::g_combat.m_ragebot.enabled || !has_weapon )
				{
					continue;
				}

				const auto active_group = &settings::g_combat.m_ragebot.get_group( ctx.weapon_type );
				auto is_active{ false };

				for ( auto i = 0u; i < settings::combat::ragebot::k_group_count; ++i )
				{
					const auto& g = settings::g_combat.m_ragebot.groups[ i ];
					if ( &g == active_group )
					{
						if ( setting == &g.min_damage_override || setting == &g.hitchance_override || setting == &g.force_shot || setting == &g.force_shot_air || setting == &g.body_aim )
						{
							is_active = true;
						}
						break;
					}
				}

				if ( !is_active )
				{
					continue;
				}

				auto& e = entries[ count++ ];
				e.name = setting->name.c_str( );
				e.mode = setting->bind.mode;

				if ( setting == &active_group->min_damage_override )
				{
					std::snprintf( e.value, sizeof( e.value ), "%d", active_group->min_damage_override_value.value );
					e.has_value_pill = true;
				}
				else if ( setting == &active_group->hitchance_override )
				{
					std::snprintf( e.value, sizeof( e.value ), "%d%%", active_group->hitchance_override_value.value );
					e.has_value_pill = true;
				}
				else
				{
					e.value[ 0 ] = '\0';
					e.has_value_pill = false;
				}
				continue;
			}

			auto is_legit_group{ false };
			for ( auto i = 0u; i < settings::combat::legitbot::k_group_count; ++i )
			{
				const auto& g = settings::g_combat.m_legitbot.groups[ i ];
				if ( setting == &g.aimbot || setting == &g.rcs || setting == &g.standalone_rcs || setting == &g.triggerbot || setting == &g.autowall || setting == &g.visualize_fov || setting == &g.trigger_head_only || setting == &g.give_me_your_seed )
				{
					is_legit_group = true;
					break;
				}
			}

			if ( is_legit_group )
			{
				if ( !settings::g_combat.m_legitbot.enabled.value || !has_weapon )
				{
					continue;
				}

				const auto* active_group = &settings::g_combat.m_legitbot.get_group( ctx.weapon_type );
				auto is_active{ false };

				for ( auto i = 0u; i < settings::combat::legitbot::k_group_count; ++i )
				{
					if ( &settings::g_combat.m_legitbot.groups[ i ] == active_group )
					{
						const auto& g = settings::g_combat.m_legitbot.groups[ i ];
						if ( setting == &g.aimbot || setting == &g.rcs || setting == &g.standalone_rcs || setting == &g.triggerbot || setting == &g.autowall || setting == &g.visualize_fov || setting == &g.trigger_head_only || setting == &g.give_me_your_seed )
						{
							is_active = true;
						}

						if ( is_active && setting == &active_group->give_me_your_seed && !active_group->triggerbot.value )
						{
							is_active = false;
						}
						break;
					}
				}

				if ( !is_active )
				{
					continue;
				}

				auto& e = entries[ count++ ];
				e.name = setting->name.c_str( );
				e.mode = setting->bind.mode;
				e.value[ 0 ] = '\0';
				e.has_value_pill = false;
				continue;
			}

			if ( setting == &settings::g_combat.m_antiaim.enabled || setting == &settings::g_combat.m_antiaim.manual_left || setting == &settings::g_combat.m_antiaim.manual_right || setting == &settings::g_combat.m_antiaim.hide_shots || setting == &settings::g_combat.m_antiaim.avoid_backstab || setting == &settings::g_combat.m_antiaim.direction_indicator )
			{
				if ( !settings::g_combat.m_antiaim.enabled.value )
				{
					continue;
				}
			}

			auto& e = entries[ count++ ];
			e.name = setting->name.c_str( );
			e.mode = setting->bind.mode;
			e.value[ 0 ] = '\0';
			e.has_value_pill = false;
		}

		if ( count > 0 )
			container_alpha.fade_in( 0.2f );
		else
			container_alpha.fade_out( 0.2f );

		container_alpha.update( );
		if ( !container_alpha.visible( ) )
			return;

		const auto master_alpha = container_alpha.alpha( );
		const auto total_h = header_h + row_spacing + ( static_cast< float >( count ) * ( row_h + row_spacing ) );
		const auto default_base_y = ( static_cast< float >( screen_h ) * 0.5f ) - ( total_h * 0.5f );

		const auto [header_tw, header_th] = xdraw::measure_text( "ACTIVE BINDS" );
		const auto count_label = std::to_string( count );
		const auto [count_tw, count_th] = xdraw::measure_text( count_label.c_str( ) );
		const auto count_pill_w = count_tw + text_pad_x * 1.5f;
		const auto header_w = inner_pad + icon_size + inner_pad + header_tw + text_pad_x * 2.0f + count_pill_w + inner_pad * 2.0f;
		auto& position = settings::g_misc;
		static bool dragging{};
		static float drag_x{};
		static float drag_y{};
		auto x = std::clamp( position.keybind_x.value, 0.0f, std::max( 0.0f, static_cast< float >( screen_w ) - header_w ) );
		auto base_ry = position.keybind_y.value >= 0.0f ? position.keybind_y.value : default_base_y;
		const auto& input = xui::ctx( ).input;
		const auto header = xui::rect{ x, base_ry, header_w, header_h };

		if ( input.mouse_clicked && header.contains( input.mouse_x, input.mouse_y ) && !xui::ctx( ).overlay_blocking( ) )
		{
			dragging = true;
			drag_x = input.mouse_x - x;
			drag_y = input.mouse_y - base_ry;
		}

		if ( !input.mouse_down )
			dragging = false;

		if ( dragging )
		{
			x = std::clamp( input.mouse_x - drag_x, 0.0f, std::max( 0.0f, static_cast< float >( screen_w ) - header_w ) );
			base_ry = std::clamp( input.mouse_y - drag_y, 0.0f, std::max( 0.0f, static_cast< float >( screen_h ) - total_h ) );
			position.keybind_x.value = x;
			position.keybind_y.value = base_ry;
		}
		const auto header_inner_h = header_h - inner_pad * 2.0f;
		const auto inner_h = row_h - inner_pad * 2.0f;
		const auto master_u8 = static_cast< std::uint8_t >( 255.0f * master_alpha );
		const auto surface_alpha = static_cast< std::uint8_t >( s.window_bg.a * master_alpha );

		// Prism Deck bind monitor: lightweight HUD card with a procedural routing icon.
		if ( osd_blur && blur_strength > 0.01f )
			draw_list.rect_filled_blurred( x, base_ry, header_w, header_h, xdraw::corner_radius{ r }, xdraw::color{ 255, 255, 255, static_cast<std::uint8_t>( master_u8 * 0.42f * blur_strength ) } );
		draw_list.rect_filled_gradient( x, base_ry, header_w, header_h,
			s.window_bg.alpha( surface_alpha ), s.child_bg.alpha( surface_alpha ), s.window_bg.alpha( surface_alpha ), s.window_bg.alpha( surface_alpha ),
			xdraw::corner_radius{ r } );
		draw_list.rect( x, base_ry, header_w, header_h, s.text.alpha( static_cast<std::uint8_t>( 24.0f * master_alpha ) ), xdraw::corner_radius{ r }, 1.0f );
		draw_list.rect_filled( x, base_ry + 5.0f, 2.0f, header_h - 10.0f, s.accent.alpha( static_cast<std::uint8_t>( 220.0f * master_alpha ) ), xdraw::corner_radius{ 1.0f } );

		const auto icx = x + inner_pad + icon_size * 0.5f;
		const auto icy = base_ry + header_h * 0.5f;
		const auto icon_col = s.accent.alpha( static_cast<std::uint8_t>( 220.0f * master_alpha ) );
		draw_list.circle( icx, icy, 5.0f, icon_col, 1.0f );
		draw_list.circle_filled( icx, icy, 1.5f, s.checkbox_mark_icon.alpha( master_u8 ) );
		draw_list.line( icx - 7.0f, icy, icx - 4.8f, icy, icon_col, 1.0f );
		draw_list.line( icx + 4.8f, icy, icx + 7.0f, icy, icon_col, 1.0f );
		draw_list.line( icx, icy - 7.0f, icx, icy - 4.8f, icon_col, 1.0f );
		draw_list.line( icx, icy + 4.8f, icx, icy + 7.0f, icon_col, 1.0f );

		const auto htx = x + inner_pad + icon_size + inner_pad;
		draw_list.text( htx, base_ry + ( header_h - header_th ) * 0.5f + text_nudge, "ACTIVE BINDS", s.text.alpha( master_u8 ) );
		const auto cpx = x + header_w - inner_pad - count_pill_w;
		draw_list.rect_filled( cpx, base_ry + inner_pad, count_pill_w, header_inner_h, s.accent.alpha( static_cast<std::uint8_t>( 32.0f * master_alpha ) ), xdraw::corner_radius{ inner_r } );
		draw_list.rect( cpx, base_ry + inner_pad, count_pill_w, header_inner_h, s.accent.alpha( static_cast<std::uint8_t>( 82.0f * master_alpha ) ), xdraw::corner_radius{ inner_r }, 1.0f );
		draw_list.text( cpx + ( count_pill_w - count_tw ) * 0.5f, base_ry + ( header_h - count_th ) * 0.5f + text_nudge, count_label.c_str( ), s.accent.alpha( master_u8 ) );

		for ( auto& [name, state] : row_states )
			state.active_this_frame = false;

		float current_offset_y = header_h + row_spacing;
		for ( auto i = 0; i < count; ++i )
		{
			const auto& e = entries[ i ];
			auto& anim = row_states[ e.name ];

			if ( !anim.active_this_frame && anim.alpha.alpha( ) <= 0.01f )
				anim.offset_y.snap( current_offset_y );

			anim.active_this_frame = true;
			anim.alpha.fade_in( 0.2f );
			anim.offset_y.set_target( current_offset_y );
			anim.alpha.update( );
			anim.offset_y.update( );

			const auto row_alpha = anim.alpha.alpha( ) * master_alpha;
			const auto draw_y = base_ry + anim.offset_y.value( );
			const auto [nw, nh] = xdraw::measure_text( e.name );
			const auto row_u8 = static_cast< std::uint8_t >( 255.0f * row_alpha );

			if ( e.has_value_pill )
			{
				const auto [vw, vh] = xdraw::measure_text( e.value );
				const auto name_pill_w = nw + text_pad_x * 2.0f;
				const auto value_pill_w = vw + text_pad_x * 2.0f;
				const auto row_w = inner_pad + name_pill_w + inner_pad + value_pill_w + inner_pad;

				if ( osd_blur && blur_strength > 0.01f )
					draw_list.rect_filled_blurred( x, draw_y, row_w, row_h, xdraw::corner_radius{ r }, xdraw::color{ 255, 255, 255, static_cast<std::uint8_t>( row_u8 * 0.34f * blur_strength ) } );
				draw_list.rect_filled_gradient( x, draw_y, row_w, row_h,
					s.child_bg.alpha( static_cast< std::uint8_t >( s.child_bg.a * row_alpha ) ),
					s.window_bg.alpha( static_cast< std::uint8_t >( s.window_bg.a * row_alpha ) ),
					s.window_bg.alpha( static_cast< std::uint8_t >( s.window_bg.a * row_alpha ) ),
					s.child_bg.alpha( static_cast< std::uint8_t >( s.child_bg.a * row_alpha ) ), xdraw::corner_radius{ r } );
				draw_list.rect( x, draw_y, row_w, row_h, s.text.alpha( static_cast<std::uint8_t>( 18.0f * row_alpha ) ), xdraw::corner_radius{ r }, 1.0f );
				draw_list.rect_filled( x, draw_y + 5.0f, 2.0f, row_h - 10.0f, s.accent.alpha( static_cast<std::uint8_t>( 185.0f * row_alpha ) ), xdraw::corner_radius{ 1.0f } );
				draw_list.text( x + inner_pad + text_pad_x, draw_y + ( row_h - nh ) * 0.5f + text_nudge, e.name, s.text.alpha( static_cast< std::uint8_t >( s.text.a * row_alpha ) ) );

				const auto vpx = x + inner_pad + name_pill_w + inner_pad;
				draw_list.rect_filled( vpx, draw_y + inner_pad, value_pill_w, inner_h, s.accent.alpha( static_cast< std::uint8_t >( 35.0f * row_alpha ) ), xdraw::corner_radius{ inner_r } );
				draw_list.rect( vpx, draw_y + inner_pad, value_pill_w, inner_h, s.accent.alpha( static_cast< std::uint8_t >( 90.0f * row_alpha ) ), xdraw::corner_radius{ inner_r }, 1.0f );
				draw_list.text( vpx + text_pad_x, draw_y + ( row_h - vh ) * 0.5f + text_nudge, e.value, s.accent.alpha( static_cast< std::uint8_t >( s.accent.a * row_alpha ) ) );
			}
			else
			{
				const auto name_pill_w = nw + text_pad_x * 2.0f;
				const auto row_w = inner_pad + name_pill_w + inner_pad;
				const auto text_col = ( e.mode == xui::bind_mode::toggle ) ? s.text_dim : s.accent;

				if ( osd_blur && blur_strength > 0.01f )
					draw_list.rect_filled_blurred( x, draw_y, row_w, row_h, xdraw::corner_radius{ r }, xdraw::color{ 255, 255, 255, static_cast<std::uint8_t>( row_u8 * 0.34f * blur_strength ) } );
				draw_list.rect_filled_gradient( x, draw_y, row_w, row_h,
					s.child_bg.alpha( static_cast< std::uint8_t >( s.child_bg.a * row_alpha ) ),
					s.window_bg.alpha( static_cast< std::uint8_t >( s.window_bg.a * row_alpha ) ),
					s.window_bg.alpha( static_cast< std::uint8_t >( s.window_bg.a * row_alpha ) ),
					s.child_bg.alpha( static_cast< std::uint8_t >( s.child_bg.a * row_alpha ) ), xdraw::corner_radius{ r } );
				draw_list.rect( x, draw_y, row_w, row_h, s.text.alpha( static_cast<std::uint8_t>( 18.0f * row_alpha ) ), xdraw::corner_radius{ r }, 1.0f );
				draw_list.rect_filled( x, draw_y + 5.0f, 2.0f, row_h - 10.0f, s.accent.alpha( static_cast<std::uint8_t>( 150.0f * row_alpha ) ), xdraw::corner_radius{ 1.0f } );
				draw_list.text( x + inner_pad + text_pad_x, draw_y + ( row_h - nh ) * 0.5f + text_nudge, e.name, text_col.alpha( static_cast< std::uint8_t >( text_col.a * row_alpha ) ) );
			}

			current_offset_y += row_h + row_spacing;
		}

		for ( auto it = row_states.begin( ); it != row_states.end( ); )
		{
			if ( !it->second.active_this_frame )
			{
				it->second.alpha.fade_out( 0.15f );
				it->second.alpha.update( );
				it->second.offset_y.update( );

				if ( it->second.alpha.alpha( ) <= 0.001f )
				{
					it = row_states.erase( it );
					continue;
				}

				const auto row_alpha = it->second.alpha.alpha( ) * master_alpha;
				const auto row_u8 = static_cast< std::uint8_t >( 255.0f * row_alpha );
				const auto draw_y = base_ry + it->second.offset_y.value( );
				const auto [nw, nh] = xdraw::measure_text( it->first.c_str( ) );
				const auto row_w = inner_pad + ( nw + text_pad_x * 2.0f ) + inner_pad;

				if ( osd_blur && blur_strength > 0.01f )
					draw_list.rect_filled_blurred( x, draw_y, row_w, row_h, xdraw::corner_radius{ r }, xdraw::color{ 255, 255, 255, static_cast<std::uint8_t>( row_u8 * 0.28f * blur_strength ) } );
				draw_list.rect_filled( x, draw_y, row_w, row_h, s.window_bg.alpha( static_cast< std::uint8_t >( s.window_bg.a * row_alpha ) ), xdraw::corner_radius{ r } );
				draw_list.rect( x, draw_y, row_w, row_h, s.text.alpha( static_cast<std::uint8_t>( 14.0f * row_alpha ) ), xdraw::corner_radius{ r }, 1.0f );
			}
			++it;
		}
	}

} // namespace rendering
