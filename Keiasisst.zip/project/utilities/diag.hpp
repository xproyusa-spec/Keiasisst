#pragma once

// Lightweight diagnostics used before the rest of the project is initialized.
// The logger deliberately uses Win32 file I/O so it remains usable from SEH
// handlers and does not depend on the state of iostreams.
namespace diag {

	enum class level {
		debug,
		info,
		warning,
		error,
		fatal
	};

	inline wchar_t g_log_path [MAX_PATH] {};
	inline wchar_t g_previous_log_path [MAX_PATH] {};
	inline wchar_t g_dump_path [MAX_PATH] {};
	inline wchar_t g_previous_dump_path [MAX_PATH] {};
	inline HANDLE g_log_file {};
	inline HMODULE g_module {};
	inline std::uintptr_t g_module_end {};
	inline thread_local std::uint32_t g_exception_scope_depth {};
	inline thread_local std::uint32_t g_probe_scope_depth {};
	inline thread_local const char* g_exception_phase {"none"};

#if defined( DEV )
	// DbgHelp declares this structure under 4-byte packing, including on x64.
#pragma pack( push, 4 )
	struct minidump_exception_information {
		DWORD thread_id;
		EXCEPTION_POINTERS* exception_pointers;
		BOOL client_pointers;
	};
#pragma pack( pop )
	static_assert(sizeof (minidump_exception_information) == 16);

	using minidump_write_fn = BOOL (WINAPI*)(
		HANDLE,
		DWORD,
		HANDLE,
		unsigned long,
		minidump_exception_information*,
		void*,
		void*);

	inline minidump_write_fn g_minidump_write {};
	inline volatile LONG g_crash_claimed {};
	inline thread_local bool g_writing_minidump {};

	struct crash_report_request {
		EXCEPTION_RECORD record {};
		CONTEXT context {};
		EXCEPTION_POINTERS pointers {};
		char stage [128] {};
		DWORD fault_thread_id {};
	};

	inline crash_report_request g_crash_request {};

	// MINIDUMP_TYPE flags from dbghelp.h. Keeping the ABI-compatible values
	// local avoids adding a static dbghelp dependency to the injected DLL.
	inline constexpr unsigned long minidump_with_unloaded_modules = 0x20;
	inline constexpr unsigned long minidump_with_indirectly_referenced_memory = 0x40;
	inline constexpr unsigned long minidump_with_thread_info = 0x1000;
	inline constexpr DWORD diagnostic_snapshot_code = 0xE0560001;
#endif

	inline const char* level_name (level) {
		return "";
	}

	inline void append_path (wchar_t*, std::size_t, const wchar_t*) {}

	inline void make_artifact_path (
		wchar_t*,
		std::size_t,
		const wchar_t*,
		const wchar_t*) {}

	inline void write (level, const char*) {
		// Loglama tamamen sessize al�nd�.
	}

	template <typename... args_t>
	inline void writef (level, const char*, args_t...) {
		// Loglama tamamen sessize al�nd�.
	}

	inline void set_module (HMODULE module_handle) {
		g_module = module_handle;
		const auto* dos_header =
			reinterpret_cast<const IMAGE_DOS_HEADER*>(module_handle);
		if (dos_header->e_magic == IMAGE_DOS_SIGNATURE) {
			const auto* nt_headers =
				reinterpret_cast<const IMAGE_NT_HEADERS*>(
					reinterpret_cast<std::uintptr_t>(module_handle) +
					dos_header->e_lfanew);
			if (nt_headers->Signature == IMAGE_NT_SIGNATURE) {
				g_module_end =
					reinterpret_cast<std::uintptr_t>(module_handle) +
					nt_headers->OptionalHeader.SizeOfImage;
			}
		}
	}

	inline void initialize_crash_dumps () {}

	inline bool is_module_address (const void* address) {
		const auto value = reinterpret_cast<std::uintptr_t>(address);
		return g_module && value >= reinterpret_cast<std::uintptr_t>(g_module) &&
			value < g_module_end;
	}

	class exception_scope {
	public:
		explicit exception_scope (const char* = "feature pipeline") {}
		~exception_scope () = default;
		exception_scope (const exception_scope&) = delete;
		exception_scope& operator=(const exception_scope&) = delete;
	};

	class probe_scope {
	public:
		probe_scope () = default;
		~probe_scope () = default;
		probe_scope (const probe_scope&) = delete;
		probe_scope& operator=(const probe_scope&) = delete;
	};

	inline bool probe_active () {
		return false;
	}

	inline void set_exception_phase (const char*) {}

#if defined( DEV )
	inline const char* exception_name (DWORD) {
		return "";
	}
	inline bool is_serious_exception (DWORD) {
		return false;
	}
	inline void format_module_address (char*, std::size_t, const void*) {}
	inline bool write_minidump (EXCEPTION_POINTERS*, DWORD) {
		return false;
	}
	inline DWORD WINAPI crash_report_thread (void*) {
		return 0;
	}
	inline void record_crash (EXCEPTION_POINTERS*, const char*) {}
	inline void capture_snapshot (const char*) {}
#else
	inline bool is_serious_exception (DWORD) {
		return false;
	}

	inline void record_crash (EXCEPTION_POINTERS*, const char*) {}

	inline void capture_snapshot (const char*) {}
#endif

	inline void step (const char*) {
		// Loglama tamamen sessize al�nd�.
	}

	inline void shutdown () {}

} // namespace diag